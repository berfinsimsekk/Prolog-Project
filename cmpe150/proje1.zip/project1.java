package project1;

public class project1 {
	public static int berfin;
	public static int berfin2;
	   public static void main(String[] args) {
		   int stickmanHeight = Integer.parseInt(args[0]);
			int stairHeight = Integer.parseInt(args[1]);
			berfin=stickmanHeight;
			berfin2=stairHeight;
			
					
		   for(int frame=1; frame<= stairHeight+1; frame++) {  //frame is the number of the pictures 
			   
			  	   
			   for(int space=1; space<= stairHeight-frame+1; space++) { //space is the number of empty lines between the head of the stickman and ceiling in the first picture and also between the pictures 
				   System.out.println();                                 
			   }
			   bodySpace(frame);
			   
			   System.out.println(" O ");
         	      
			   bodySpace(frame);			   
			   
			   System.out.println("/|\\ "); 
			   
			   bodySpace(frame);
			   
			   for(int justBody=1; justBody<=stickmanHeight-stairHeight+frame-4; justBody++) {  // justBody is the number of torso of the stickman which is above the stairs
				   System.out.println(" | ");                                               
				   bodySpace(frame);
				  
			   }
			   
			   for(int bodyWithStair=1; bodyWithStair<=stairHeight-frame+1; bodyWithStair++) { // bodyWithStair is the number of torso of the stickman which is on the stairs
				   System.out.print(" | ");                                                    
			   
		          for(int gap=1; gap<=(frame*-3)+(bodyWithStair*-3)+(stairHeight*3+6); gap++) { // gap is the number of space between torso and stair
					   System.out.print(" ");
					   
				   }
		          
		          bottomLine();
		          line();
				  
		          for(int star=1; star<=bodyWithStair*3-3; star++) { // star is the number of stars inside the stairs
					   star();
						
					   }
				   wall();
				   bodySpace(frame);
				   
				   }
			  
			   System.out.print("/ \\");
			   
			   bottomLine();  
			   line();
			   
			   for(int star=1; star<=(3*stairHeight)-3*(frame-1); star++) { //star is the number of stars which are in the same line with stickman's legs
				   star();                                                  
			   }
			   wall();
			  
			   for(int spaceForStair=1; spaceForStair<=frame-1; spaceForStair++) { // spaceForStair is the number of stairs which are under the stickman
				                                                                  
			   for(int forStair=1; forStair<=(frame*3)-(3*spaceForStair); forStair++){// forStair is the number of spaces which comes before the stairs that are under the stickman
                                                                                      
				   System.out.print(" ");
			   }
			  
			   bottomLine();
			   line();
			   
			   for(int starForStair=1; starForStair<=3*(stairHeight+spaceForStair-frame+1); starForStair++) { // starForStair is the number of stars which are inside the stairs that under stickman
				   star();                                                                                   
			   }
			   wall();
			   }
				  
			   
			   for(int frameSpace=1; frameSpace<=3; frameSpace++) { //frameSpace is the number of empty lines between pictures
				   System.out.println();
			   }
			   
		
		   
			   }
	}
	   /*This method prints the spaces between stickman and 
	    * the left side of the console
	    */
	   
	   public static void bodySpace(int frame) {
		   for(int space=1; space<=3*frame-3; space++) {
			   System.out.print(" ");
			   
		   }
	   }
	   
	   /*This method prints the step line
	    * of the stair
	    */
	  
	   public static void bottomLine() {
		   for(int bottomLine=1; bottomLine<=3; bottomLine++) {
			   System.out.print("_");
		   }
	   }
	   
	   /*This method prints the line 
	    * which comes just after the bottomLines
	    */
	   public static void line() {
		   System.out.print("|");
	   }
	   
	   /*This method prints the stars inside
	    * the stairs
	    */
	   public static void star() {
		   System.out.print("*");
	   }
	   
	   /*This method prints lines 
	    * which are at the end of the each step
	    */
	   public static void wall() {
		   System.out.println("|");
	   }
	   }


