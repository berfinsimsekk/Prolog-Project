import java.util.*;

public class BS2018400009 {
	public static void main(String[] args) {
		
		Scanner console = new Scanner(System.in);
		String v= console.nextLine();
		String Q= console.nextLine();
		String w= console.nextLine();
		String x= console.nextLine();
		
		x=input(v,x);		//to change the intput names
		x=input(Q,x);		//with their original
		x=input(w,x);       //values     
		

		double newnumber=0;
    
    for(int q=0; q<x.length(); q++) {  //nested parentheses   //it checks whether there are nested parentheses
    	if(x.charAt(q)=='(') {
    		String ef=x.substring(x.indexOf(x.charAt(q))+1);//it takes inside the parentheses
    	
    		for(int f=0; f<ef.indexOf(")"); f++) {
    			if(ef.charAt(f)=='(') { // it checks whether there is another parentheses inside the parenthes
    				  
    					
    						String insideprth=ef.substring(ef.indexOf("(")+1,ef.indexOf(")")); // it takes inside the nested parentheses
    						
    						insideprth=multiplicationdivision(insideprth,0);  //it evaluates the multiplication-division operations if there are any
    						insideprth=additionsubtraction(insideprth,0); //it evaluates the addition-subtraction operations if there are any
    				
    					  x=x.substring(0,x.indexOf("(")+1) +ef.substring(0,ef.indexOf("("))+ insideprth + ef.substring(ef.indexOf(")")+1); //to change the nested parentheses with the operation results which they have inside the brackets
    					
    			}else {
    				continue;
    			}
    		}
    	}if(x.charAt(q)==')') { //to check whether the parentheses close 
    		break;
    	}else {
    		continue;
    	}
    }
    		
    for(int z=0; z<x.length();z++) {  //it checks whether there are parentheses
	if(x.charAt(z)=='(') {
		String insideprth=x.substring(x.indexOf("(")+1,x.indexOf(")")); //to take the inside of brackets
		insideprth= multiplicationdivision(insideprth,0); //it evaluates the multiplication-division operations if there are any
		insideprth= additionsubtraction(insideprth,0); //it evaluates the addition-subtraction operations if there are any

	   x=x.substring(0,x.indexOf("(")) + insideprth + x.substring(x.indexOf(")")+1);//to change the parentheses with the operation results which they have inside the brackets
	
}if(x.charAt(z)==')') {//to check whether the parentheses close 
	 break;
}else {
	continue;
}
}

    x=multiplicationdivision(x,0); //it evaluates the multiplication-division operations if there are any
   x=additionsubtraction(x,0); //it evaluates the addition-subtraction operations if there are any
    	
	if(x.charAt(x.length()-1)==')'||x.charAt(x.length()-1)==';') { //if there are any brackets left in the string it collapses them
		x=x.substring(0,x.length()-1);
	}
	
	System.out.println(x);

}
	public static String additionsubtraction(String x, double newnumber) { //this method evaluates the addition-subtraction operations 
		
		for(int i=0; i<x.length(); i++) { 
			 int w=0;
			 int y=0;
			double firstnum=0; 
			double secondnum=0;
			double k=0.0;
			double firstdouble=0;
			double afterdot=0.0;
			double afterdot2=0.0;
			double beforedot=0.0;
			int doublexits=0;
				
				if(x.charAt(i)=='+'|| x.charAt(i)== '-') { //to find the operators
					String before= x.substring(0,x.indexOf(x.charAt(i))); //it takes the number before the operator
					
					int j=0;
					
					for(int m=before.length()-1; m>=0; m--) {
						  
						if(before.charAt(m)=='.') { //to check whether the number is double
						 doublexits++;
						 w++;
							afterdot= firstnum/Math.pow(10, k); //to change the number to double
							firstnum=0;
							j=0;
							m--;
							while(m>=0) {
								 if(before.charAt(m)<='9'&& before.charAt(m)>='0') { //to check whether it is a number or not
										firstnum= (int) (firstnum + (before.charAt(m)-'0')*(Math.pow(10, j))); //to get the number
										j++;
										k++;
										w++;
										
									} if(j>=1 && (before.charAt(m)>'9' || before.charAt(m)<'0') ) { //if it not a number it breaks
									  
										break;
										
									}
									m--;
							}
							 firstnum=firstnum/1.0; //changes it to double
								firstnum= firstnum+afterdot; 
								
							break;
						}
						
						 if(before.charAt(m)<='9'&& before.charAt(m)>='0') { //to check whether it is number or not
							firstnum= (int) (firstnum + (before.charAt(m)-'0')*(Math.pow(10, j))); //to get the number
							j++;
							k++;
							
						} if(j>=1 && (before.charAt(m)>'9' || before.charAt(m)<'0') ) { //if it is not a number it breaks
						
							break;
							
						}
						w++;
						
					}
				
				String after= x.substring(x.indexOf(x.charAt(i))+1); //to get the number after the operator
				int count=0;
				int count2=0;
				for(int k1=0; k1<after.length(); k1++) {
					
					if(after.charAt(k1)<='9' && after.charAt(k1)>='0') { //to check whether it is a number or not
						if(count2>0) {
							count2++;
							y++;//counts the digit
							continue;
						}
						count++;
					}if(after.charAt(k1)=='.') { //to check whether the number is a double
						count2++;
						y++;
						continue;
					}
					if(count>=1 && (after.charAt(k1)>'9' || after.charAt(k1)<'0')) { //if it is not anumber it breaks
						break;
					}
					y++;
				}
				count2--;
				
				int say�=count2;
				for(int s=0; s<after.length(); s++) {
				if(after.charAt(s)=='.') { //to check whether it is double or not
					doublexits++;
					
					beforedot=secondnum/1.0; //change the number to double
					secondnum=0;
					
					for(int w1=after.indexOf(".")+1; w1<after.length(); w1++) { //to get the number after the dot of the double
						if(after.charAt(w1)<='9' && after.charAt(w1)>='0') {
							afterdot2=(int) (afterdot2 + (after.charAt(w1)-'0')*(Math.pow(10,(count2)-1)));
							count2--;
						}if(count2<=0) {
							afterdot2=afterdot2/(Math.pow(10, say�)); //to change the number to double
							break;
						}
					}
					
					secondnum=beforedot+afterdot2;
					
					break;
						
				}if(after.charAt(s)<='9' && after.charAt(s)>='0') { //to check whether it is a number
					secondnum=(int) (secondnum+(after.charAt(s)-'0')*(Math.pow(10, count-1))); 
				count--;
			    }if(count<=0 && count2==0) {
						break;
				}if(after.charAt(s)>'9' || after.charAt(s)<'0') { //for the empty spaces before the number
						continue;
					}
				
					}
			  if(x.charAt(i)=='+'&& doublexits>0) { //if the operator is + and there is double number
				newnumber= firstnum+ secondnum;
				String newline=newnumber+ "";
				x=x.substring(0,before.length()-w)+ newline+ after.substring(y); //it changes the operation with the result of the operation
		    }else if(x.charAt(i)=='-'&& doublexits>0) { //if the operator is - and there is double number
		    	newnumber= firstnum-secondnum;
		    	String newline=newnumber+ "";
		    	x=x.substring(0,before.length()-w)+ newline+ after.substring(y); //it changes the operation with the result of the operation
		    }else if(x.charAt(i)=='+'&& doublexits==0) { //if the operator is + and there is no double number
		    	newnumber= (int)firstnum+(int)secondnum;
		    	String newline=(int)newnumber+ "";
		    	x=x.substring(0,before.length()-w)+ newline+ after.substring(y); //it changes the operation with the result of the operation
		    }else if(x.charAt(i)=='-'&& doublexits==0) { //if the operator is - and there is no double number
		    	newnumber= (int)firstnum-(int)secondnum;
		    	String newline=(int)newnumber+ "";
		    	x=x.substring(0,before.length()-w)+ newline+ after.substring(y); //it changes the operation with the result of the operation
		    }
		    
				
		     i=0;
			}
				
		}
		for(int abc=0; abc<x.length(); abc++) { // to collapse the empty spaces
			if(x.charAt(abc)==' ') {
				x=x.substring(0,x.indexOf(" ")) + x.substring(x.indexOf(" ")+1);
				abc--;
			}
		}
		return x;
	}
	
	
	public static String multiplicationdivision(String x, double newnumber) {//this method evaluates the multiplication-subtraction operations 
		
	
		for(int i=0; i<x.length(); i++) {  //�arpmab�lme
	    	 int w=0;
	    	 int y=0;
	    	double firstnum=0; 
	    	double secondnum=0;
	    	double k=0.0;
	    	double firstdouble=0;
	    	double afterdot=0.0;
	    	double afterdot2=0.0;
	    	double beforedot=0.0;
	    	int doublexist=0;
	    		
	    		if(x.charAt(i)=='*'|| x.charAt(i)== '/') { //to find the operators
	    			String before= x.substring(0,x.indexOf(x.charAt(i)));//it takes the number before the operator
	    			
	    			int j=0;
	    			
	    			for(int m=before.length()-1; m>=0; m--) {
	    				  
	    				if(before.charAt(m)=='.') { //to check whether the number is double
	    				 doublexist++;
	    				 w++;
	    					afterdot= firstnum/Math.pow(10, k); //to change the number to double
	    					firstnum=0;
	    					j=0;
	    					m--;
	    					while(m>=0) {
	    						 if(before.charAt(m)<='9'&& before.charAt(m)>='0') { //to check whether it is a number or not
	    								firstnum= (int) (firstnum + (before.charAt(m)-'0')*(Math.pow(10, j))); //to get the number
	    								j++;//it counts the digits
	    								k++;
	    								w++;
	    								
	    							} if(j>=1 && (before.charAt(m)>'9' || before.charAt(m)<'0') ) { //if there is empty spaces after number it breaks
	    							  
	    								break;
	    								
	    							}
	    							m--;
	    					}
	    					 firstnum=firstnum/1.0; //to change the number to double
	    						firstnum= firstnum+afterdot;
	    						
	    					break;
	    				}
	    				
	    				 if(before.charAt(m)<='9'&& before.charAt(m)>='0') { //to check whether it is a number ot rnot
	    					firstnum= (int) (firstnum + (before.charAt(m)-'0')*(Math.pow(10, j))); //to get the number
	    					j++;
	    					k++;
	    					
	    				} if(j>=1 && (before.charAt(m)>'9' || before.charAt(m)<'0') ) { // if there is empty spaces after the number it breaks
	    				
	    					break;
	    					
	    				}
	    				w++;
	    				
	    			}
	    		
	    		String after= x.substring(x.indexOf(x.charAt(i))+1); // it takes the number after the operator
	    		int count=0;
	    		int count2=0;
	    		for(int k1=0; k1<after.length(); k1++) {
	    			
	    			if(after.charAt(k1)<='9' && after.charAt(k1)>='0') { //to check whether it is a number or not
	    				if(count2>0) {
	    					count2++;
	    					y++;
	    					continue;
	    				}
	    				count++;
	    			}if(after.charAt(k1)=='.') { //to check whether it is double 
	    				count2++;
	    				y++;
	    				continue;
	    			}
	    			if(count>=1 && (after.charAt(k1)>'9' || after.charAt(k1)<'0')) { //if there is empty spaces after the number it breaks
	    				break;
	    			}
	    			y++;
	    		}
	    		count2--;
	    		
	    		
	    		int say�=count2;
	    		for(int s=0; s<after.length(); s++) {
	    		if(after.charAt(s)=='.') { //to check whether it is double
	    			doublexist++;	
	    			beforedot=secondnum/1.0;   			
	    			secondnum=0;
	    			
	    			for(int w1=after.indexOf(".")+1; w1<after.length(); w1++) { //to get the number after the dot of the double
	    				if(after.charAt(w1)<='9' && after.charAt(w1)>='0') { //to check whether it is a number 
	    					afterdot2=(int) (afterdot2 + (after.charAt(w1)-'0')*(Math.pow(10,(count2)-1))); // to get the number
	    					count2--;
	    				}if(count2<=0) {
	    					afterdot2=afterdot2/(Math.pow(10, say�)); //to change the number to double
	    					break;
	    				}
	    			}
	    			
	    			secondnum=beforedot+afterdot2; //to add the numbers before and after the dots
	    			
	    			break;
	    			
	    			
	    		}if(after.charAt(s)<='9' && after.charAt(s)>='0') { //to check whether it is number or not
	    			secondnum=(int) (secondnum+(after.charAt(s)-'0')*(Math.pow(10, count-1))); //to get the number
	    		count--;
	    	    }if(count<=0 && count2==0) { //if the number ends it breaks
	    				break;
	    		}if(after.charAt(s)>'9' || after.charAt(s)<'0') { //if there are any empty spaces before the number it continues
	    				continue;
	    			}
	    		
	    			}
		
	        if(x.charAt(i)=='*'&& doublexist>0) { //if the operator is * and there is double
	    		newnumber= firstnum* secondnum;
	    		String newline=newnumber+ "";
	    		x=x.substring(0,before.length()-w)+ newline+ after.substring(y);
	        }else if(x.charAt(i)=='/'&& doublexist>0) {//if the operator is / and there is double
	        	newnumber= firstnum/secondnum;
	        	String newline=newnumber+ "";
	        	x=x.substring(0,before.length()-w)+ newline+ after.substring(y);
	        }else if(x.charAt(i)=='*'&& doublexist==0) {//if the operator is * and there no double
	        	newnumber= (int)firstnum*(int)secondnum;
	        	String newline=(int)newnumber+ "";
	        	x=x.substring(0,before.length()-w)+ newline+ after.substring(y);
	        }else if(x.charAt(i)=='/'&& doublexist==0) {//if the operator is / and there no double
	        	newnumber= (int)firstnum/(int)secondnum;
	        	String newline=(int)newnumber+ "";
	        	x=x.substring(0,before.length()-w)+ newline+ after.substring(y); //it changes the operation with the result of the operation
	        }
   		
	         i=0;
	        
	    	}
	    

	    }
		for(int abc=0; abc<x.length(); abc++) { // to collapse the empty spaces
			if(x.charAt(abc)==' ') {
				x=x.substring(0,x.indexOf(" ")) + x.substring(x.indexOf(" ")+1);
				abc--;
			}
		}
	return x;

}

	public static String input(String v,String x) { //This method change the variable names with their original value and add them in the string
	
		double n1=0.0;
		int y=0;
		int doublexist=0;
		double beforedot=0.0;
		double afterdot2=0.0;
			String def=v.substring(v.indexOf("=")+1,v.indexOf(";"));// to take the variable that user enters
			int count=0;
    		int count2=0;//it changes only there is double
    		for(int k1=0; k1<def.length(); k1++) {
    			
    			if(def.charAt(k1)<='9' && def.charAt(k1)>='0') { //to check whether it is a number or not
    				if(count2>0) {
    					count2++;
    					y++;// it counts the digit of the number
    					continue;
    				}
    				count++;
    			}if(def.charAt(k1)=='.') { // to check whether it is double
    				count2++;
    				y++;
    				continue;
    			}
    			if(count>=1 && (def.charAt(k1)>'9' || def.charAt(k1)<'0')) { //if the number ends, it breaks
    				break;
    			}
    			y++;
    		}
    		count2--;
    		
    		int num=count2;
    		for(int s=0; s<def.length(); s++) {
    		if(def.charAt(s)=='.') {//to check whether it is double
    			doublexist++;
    			
    			beforedot=n1/1.0;	//to change the number into double
    			n1=0;
    			
    			for(int w1=def.indexOf(".")+1; w1<def.length(); w1++) { //evaluates the number after the dot 
    				if(def.charAt(w1)<='9' && def.charAt(w1)>='0') {
    					afterdot2=(int) (afterdot2 + (def.charAt(w1)-'0')*(Math.pow(10,(count2)-1)));
    					count2--;
    				}if(count2<=0) {
    					afterdot2=afterdot2/(Math.pow(10, num));//to change the number into double
    					break;
    				}
    			}
    			
    			n1=beforedot+afterdot2;
    			
    			break;
    			
    			
    		}if(def.charAt(s)<='9' && def.charAt(s)>='0') { //to check whether it is a number
    			n1=(int) (n1+(def.charAt(s)-'0')*(Math.pow(10, count-1))); //if it is double it evaluates the number before the dot, if it is integer it is the numbers itself
    		count--;
    	    }if(count<=0 && count2==0) {
    				break;
    		}if(def.charAt(s)>'9' || def.charAt(s)<'0') { //if it is not a number it continues
    				continue;
    			}
    		
    			}
    		for(int abc=0; abc<def.length(); abc++) { //this for loop collapses the empty spaces
    			if(def.charAt(abc)==' ') {
    				def=def.substring(0,def.indexOf(" ")) + def.substring(def.indexOf(" ")+1);
    				abc--;
    			}
    		}

	String name="";
	if(v.substring(0,3).equals("int")) { //to check whether it is integer
		
		
		for(int yb=3; yb<v.indexOf("=");yb++) {
			
		if(v.charAt(yb)<='z'&& v.charAt(yb)>='a' || v.charAt(yb)>='A' && v.charAt(yb)<='Z') { //to get its name
			name=name + v.charAt(yb); 
			
		}
		}
		int length=name.length();
	for(int ey=0; ey<x.length(); ey++) {
		if(ey+length>x.length()) {//to avoid out of range exception
			break;
		}if(ey+length==x.length()) {
			if(x.substring(ey).equals(name)) {
				x=x.substring(0,ey) + (int)n1 +x.substring(ey+length);//it adds the number in the string instead the name
				ey=0;
				if(x.length()<length) {
					break;
				}
			}
			break;
		
	}if(x.substring(ey,ey+length).equals(name)) {
			x=x.substring(0,ey) + (int)n1 +x.substring(ey+length);
			ey=0;
			if(x.length()<length) {
				break;
			}
       }
		 
	}
	
	}if(v.substring(0,6).equals("double")) {//to check whether it is double
		for(int yb=6; yb<v.indexOf("=");yb++) {
			
			if(v.charAt(yb)<='z'&& v.charAt(yb)>='a' || v.charAt(yb)>='A' && v.charAt(yb)<='Z') {//to get its name
				name=name + v.charAt(yb);
				
			}
			}
		
			int length=name.length();
		for(int ey=0; ey<x.length(); ey++) {
			if(ey+length>x.length()) {//to avoid out of range
				break;
			}if(ey+length==x.length()) {
				if(x.substring(ey).equals(name)) {
					x=x.substring(0,ey) + (int)n1 +x.substring(ey+length);//it adds the number in the string instead the name
					ey=0;
					if(x.length()<length) {
						break;
					}
				}
				break;
			}if(x.substring(ey,ey+length).equals(name)) {
				x=x.substring(0,ey) + (double)n1 +x.substring(ey+length);
				ey=0;
				if(x.length()<length) {
					break;
				}
	       }
			 
		
		}
	}
	
	return x;

}
}
