import java.io.*;
import java.util.Scanner;
public class BS2018400009 {
	

		public static void main(String[] args) throws FileNotFoundException {
			int mode= Integer.parseInt(args[0]); //takes the mode from user
			String inputname= args[1]; //takes the name of file from user
			
			Scanner scan = new Scanner(new File(inputname));
			int row=0;
			int column=0;
			String first=scan.nextLine(); //takes the first line of the file
			while(scan.hasNextLine()) {
				String line=scan.nextLine(); 
				Scanner lineScan=new Scanner(line);
				
				if(lineScan.hasNextInt()) {
					column=lineScan.nextInt(); //takes the number of rows
					row=lineScan.nextInt(); //takes the number of columns
				    break;
				}
				
			}
			String max=scan.nextLine();	//takes the maximum number that file has
			
			int[][][] array= new int[row][column][3];
			createarray(array,row,column,scan);  // creates an array with the numbers that file has
					
			//part2
			if(mode==0) {
			
			PrintStream output= new PrintStream(new File("output.ppm")); //creates a file named output.ppm 
			method1(array,output,row,column,first,max); //write the numbers that array has into file
			}
		
			//part3blackandwhite
			else if(mode==1) {
			
			PrintStream output2= new PrintStream(new File("black-and-white.ppm"));//creates a file named black-and-white.ppm
			int sum=0;
			for(int i=0; i<row; i++) {
				for(int k=0; k<column; k++) {
					for(int m=0; m<3; m++) {
						sum+=array[i][k][m]; //adds the different channels' number to get the sum of them
					}
					array[i][k][0]=(int)sum/3; //takes the average of the sum 
					array[i][k][1]=(int)sum/3; //takes the average of the sum
					array[i][k][2]=(int)sum/3; //takes the average of the sum
					sum=0; //resets the sum
				}
			}
			method1(array,output2,row,column,first,max); //write the numbers into file
			}
		
			//part4
			else if(mode==2) {
				String filtername= args[2]; //takes the filter's name from user
			
			Scanner scan2 = new Scanner(new File(inputname));
			int row2=0;
			int column2=0;
			String first2=scan2.nextLine(); //takes the first line of the file
			while(scan2.hasNextLine()) {
				String line=scan2.nextLine();
				Scanner lineScan=new Scanner(line);
				
				if(lineScan.hasNextInt()) {
					column2=lineScan.nextInt(); //takes the number of rows
					row2=lineScan.nextInt();  //takes the number of columns
				    break;
				}
				
			}
			String max2=scan2.nextLine(); //takes the maximum number that file has
			
			int[][][] array2= new int[row2][column2][3];
			createarray(array2,row2,column2,scan2);  // creates an array with the numbers that file has
			
			
			Scanner scanfilter= new Scanner(new File(filtername)); //scans the filter
			String forarray=scanfilter.nextLine();
			String forrow= forarray.substring(0,1); //takes the number of rows as a string
			String forcolumn= forarray.substring(2); //takes the number of columns as a string
			int roww=Integer.parseInt(forrow); // changes the string to integer
			int columnn=Integer.parseInt(forcolumn); //changes the string to integer
			int[][] filterarray = new int [roww][columnn]; 
			for(int i=0; i<roww; i++) {
			   if(scanfilter.hasNextLine()) {
				   String linee=scanfilter.nextLine();
				   Scanner lineeScan= new Scanner(linee);
				   for(int k=0; k<columnn; k++) {
					   if(lineeScan.hasNextInt()) {
						   filterarray[i][k]=lineeScan.nextInt(); // creates an array with the numbers that filter file has
					   }
					   }
				   }
			   }
				
			PrintStream outputconv= new PrintStream(new File("convolution.ppm")); //creates a file named convolution.ppm 
			
			int[][][] sumarray=new int[row2-roww+1][column2-columnn+1][3];
			
			int summ=0;
			int summ2=0;
			int summ3=0;
		
			for(int times=0; times<row-roww+1; times++) { //times represents the rows of sumarray
				for(int k=0; k<column-columnn+1; k++) { // k represents the columns of sumarray
				  for(int i=times,d=0;d<roww && i<row;d++, i++) { //i represents the rows of array2 and d represents the rows of filterarray
					for(int k2=k,m=0; m<columnn && k2<column; k2++,m++) { //k2 represents the columns of array2 and m represents the columns of filterarray
							summ+=array2[i][k2][0]*filterarray[d][m];  //convolution operations
							summ2+=array2[i][k2][1]*filterarray[d][m];
							summ3+=array2[i][k2][2]*filterarray[d][m];

						}
					
						}
				  if(summ<0) { //if sum is a negative number it becomes 0
					  summ=0;
				  }if(summ>255) { //if sum is bigger than 255 it becomes 255
					  summ=255;
				  } if(summ2<0) {
					  summ2=0;
				  }if(summ2>255) {
					  summ2=255;
				  }
				  if(summ3<0) {
					  summ3=0;
				  }if(summ3>255) {
					  summ3=255;
				  }
				  int sumx=(int)(summ+summ2+summ3)/3; //takes the average of the sums in order to make the image black and white
				  sumarray[times][k][0]=sumx;
				  sumarray[times][k][1]=sumx;
				  sumarray[times][k][2]=sumx;

					summ=0; //resets the sums
					summ2=0;
					summ3=0;
					
					}
				
				}
			
			method1(sumarray,outputconv,row2-roww+1,column2-columnn+1,first,max);//write the numbers into file
			
			
			}
			
			//part5
			else if(mode==3) {
				int range = Integer.parseInt(args[2]); // takes the range from user
			Scanner scan3 = new Scanner(new File(inputname));
			int row3=0;
			int column3=0;
			String first3=scan3.nextLine(); //takes the first line of the file
			while(scan3.hasNextLine()) {
				String line=scan3.nextLine();
				Scanner lineScan=new Scanner(line);
				
				if(lineScan.hasNextInt()) {
					column3=lineScan.nextInt(); //takes the number of rows
					row3=lineScan.nextInt(); //takes the number of columns
				    break;
				}
				
			}
			String max3=scan3.nextLine(); //takes the maximum number that file has
			
			int[][][] array3= new int[row3][column3][3];
			createarray(array3,row3,column3,scan3); // creates an array with the numbers that file has
			
			boolean[][][] checker = new boolean[row3][column3][3]; // to check whether the pixel has checked or not
			
	      for(int deep=0; deep<3; deep++) { //deep represents 3rd dimension 
	    	  for(int r=0; r<row3; r++) { //r represents rows
	    		  for(int c=0; c<column3; c++) { //c represents columns
	    			  if(checker[r][c][deep]== true) { // if the pixel has checked or changed before it doesn't change again
	    				  continue;
	    			  }
	    			  quantized(array3,checker,range,r,c,deep); //check the numbers' neighbors whether they are in the range or not if they are in the range they change 
	    		  }
	    	  }
	      }
	     
			PrintStream quantized = new PrintStream(new File("quantized.ppm")); //creates a file named quantized.ppm 
			method1(array3,quantized,row3,column3,first3,max3); //write the numbers into file
			}
			
	}
		public static int[][][] quantized(int[][][] array,boolean[][][] check,int range,int r,int c,int d) {
			//this method checks the numbers' neighbors whether they are in the range or not
			check[r][c][d]=true; //to specify the number has checked
			if(c!=array[r].length-1 &&check[r][c+1][d]!=true && array[r][c][d]+range>=array[r][c+1][d] && array[r][c][d]-range<=array[r][c+1][d]) {
				//if column isn't at the rightmost edge and hasn't checked and in the range 
				array[r][c+1][d]=array[r][c][d]; //changes the value of the neighbor
				check[r][c+1][d]=true; //to specify it has changed
				quantized(array,check,range,r,c+1,d); //recursion part
		   }if(c!=0  && check[r][c-1][d]!=true && array[r][c][d]+range>=array[r][c-1][d] && array[r][c][d]-range<=array[r][c-1][d]) {
			 //if column isn't at the leftmost edge and hasn't checked and in the range 
			   array[r][c-1][d]=array[r][c][d];
			   check[r][c-1][d]=true; 
			quantized(array,check,range,r,c-1,d); 
	       }if(r!= array.length-1 && check[r+1][c][d]!=true&& array[r][c][d]+range>=array[r+1][c][d] && array[r][c][d]-range<=array[r+1][c][d]) {
	    	 //if row isn't at the bottommost edge and hasn't checked and in the range 
	    	   array[r+1][c][d]=array[r][c][d];
	    	   check[r+1][c][d]=true;
			   quantized(array,check,range,r+1,c,d);
			}if(r!=0 && check[r-1][c][d]!=true  && array[r][c][d]+range>=array[r-1][c][d] && array[r][c][d]-range<=array[r-1][c][d]) {
				//if row isn't 0 and hasn't checked and in the range 
				array[r-1][c][d]=array[r][c][d];
				check[r-1][c][d]=true;
				quantized(array,check,range,r-1,c,d);
			}if(d!=2 && check[r][c][d+1]!=true  && array[r][c][d]+range>=array[r][c][d+1] && array[r][c][d]-range<=array[r][c][d+1]) {
				//if deep isn't 2 and hasn't checked and in the range 
				array[r][c][d+1]=array[r][c][d];
				check[r][c][d+1]=true;
				quantized(array,check,range,r,c,d+1);
		  }if(d!=0 && check[r][c][d-1]!=true && array[r][c][d]+range>=array[r][c][d-1] && array[r][c][d]-range<=array[r][c][d-1]) {
			//if deep isn't 0 and hasn't checked and in the range 
			  array[r][c][d-1]=array[r][c][d];
			check[r][c][d-1]=true;
			quantized(array,check,range,r,c,d-1);
	}
		
	    return array;
	       }
		
		public static void method1 (int [][][] a, PrintStream name,int row,int column, String first,String max) {
			//this method prints the number that array has into file 
			name.println(first);
			name.print(row +" ");
			name.println(column);
			name.println(max);
			for(int i=0; i<row; i++) {
				for(int k=0; k<column; k++) {
					for(int m=0; m<3; m++) {
						name.print(a[i][k][m] + " ");
					}
					name.print("\t");
				}
				name.println();
			}
		}
		
		public static void createarray (int[][][] array, int row,int column,Scanner scan) {
			//this method creates an array with the numbers that file has
			for(int i=0; i<row; i++) {
				if(scan.hasNextLine()) {
					   String line=scan.nextLine();
					   Scanner lineScan=new Scanner(line);		
				for(int k=0; k<column; k++) {
							for(int m=0; m<3; m++) { 
								if(lineScan.hasNextInt()) {
								array[i][k][m]=lineScan.nextInt();
								}
								}
							
							}
						}
					}
		}
		
		}
	        


